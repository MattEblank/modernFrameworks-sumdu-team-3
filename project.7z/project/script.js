var arr= [['<input type="checkbox">',"2"],
          ['<input type="checkbox">',"5"]];
var table = document.querySelector('#table1');          

function clearTable(){
    var tableNode = document.getElementById("table1");
    while (tableNode.firstChild) {
        tableNode.removeChild(tableNode.firstChild);
    }
}

function create(){
              fillTable(table, arr);
}

function fillTable(table, arr){
                for (var i=0; i<arr.length; i++){
                    var tr=document.createElement('tr');
                    for(var j=0; j<arr[i].length; j++){
                        var td = document.createElement('td');
                        td.innerHTML=arr[i][j];
                        tr.appendChild(td);
                    }
                    document.querySelector('#table1').appendChild(tr);
                }
}

function addSubj(){
    var Elem = document.AddForm.SNameAdd.value;
    clearTable();
    arr.push(['<input type="checkbox">',Elem]);
    create();
    document.getElementById("sadd").reset();
    document.location.href = "#close";
}

function editSubj(){
    var elem2 = document.EditForm.SNameEdit.value;
    
    var inputs = document.querySelector('#table1').getElementsByTagName("input");
    var i = inputs.length;
    while (i--) {
        var input = inputs[i];
        if (input.checked == true) {
            var tr = input.parentNode.parentNode;
            tr.childNodes[1].innerHTML=elem2;
            }
        }
    document.getElementById("sedit").reset();
    document.location.href = "#close";
    tableToArray();
}

function deleteSubj(row){
    var i = row.parentNode.parentNode.rowIndex;
    document.getElementById("table1").deleteSubj(i);
}

function tableToArray(){
    arr = [];
$('table tr').each(function(){
    var array_row = [];
   $(this).find('td:eq(1)').each(function(){
       array_row.push('<input type="checkbox">',$(this).text());
   });
   arr.push(array_row);
});
}

function deleteRows() {
        var inputs = document.querySelector('#table1').getElementsByTagName("input");
        var i = inputs.length;
        while (i--) {
            var input = inputs[i];
            if (input.checked == true) {
                var tr = input.parentNode.parentNode;
                document.querySelector('#table1').deleteRow(tr.rowIndex);
            }
        }
        tableToArray();
}

function getSelectedRowValue(){
    var inputs = document.querySelector('#table1').getElementsByTagName("input");
        var i = inputs.length;
        while (i--) {
            var input = inputs[i];
            if (input.checked == true) {
                var tr = input.parentNode.parentNode;
                var val=tr.childNodes[1].innerHTML;
                }
            }
            return val;
}

function selectedValueToForm(){
    document.EditForm.SNameEdit.value=getSelectedRowValue();
}